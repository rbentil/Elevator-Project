#include <iostream>
#include <vector>
using namespace std;

class Elevator {
public:
    Elevator(int capacity, int numFloors) : capacity(capacity), currentFloor(), numFloors(numFloors) {}

    void addPassenger() {
        if (passengers.size() < capacity) {
            passengers.push_back(1);
        }
        else {
            cout << "Elevator is full" << endl;
        }
    }

    void removePassenger() {
        if (!passengers.empty()) {
            passengers.pop_back();
        }
        else {
            cout << "Elevator is empty" << endl;
        }
    }

    void requestFloor(int floor) {
        if (floor > 0 && floor <= numFloors) {
            floorsToVisit.push_back(floor);
        }
        else {
            cout << "Invalid floor" << endl;
        }
    }

    void move() {
        if (!floorsToVisit.empty()) {
            int nextFloor = floorsToVisit.front();
            floorsToVisit.erase(floorsToVisit.begin());
            if (nextFloor > currentFloor) {
                cout << "Moving up to floor " << nextFloor << endl;
                currentFloor = nextFloor; // update current floor
            }
            else if (nextFloor < currentFloor) {
                cout << "Moving down to floor " << nextFloor << endl;
                currentFloor = nextFloor; // update current floor
            }
            else {
                cout << "Already on floor " << currentFloor << endl;
            }
        }
    }


    int getCurrentFloor() const {
        return currentFloor;
    }

    int getNumPassengers() const {
        return passengers.size();
    }

    vector<int> getFloorsToVisit() const {
        return floorsToVisit;
    }

private:
    int capacity;
    int currentFloor;
    int numFloors;
    vector<int> floorsToVisit;
    vector<int> passengers;
};

int main() {
    // create elevator with capacity 10 and 5 floors
    Elevator elevator(10, 5);

    // add and remove passengers
    elevator.addPassenger();
    elevator.addPassenger();
    elevator.addPassenger();
    elevator.addPassenger();
    elevator.addPassenger();
    elevator.addPassenger();
    elevator.addPassenger();
    elevator.addPassenger();
    elevator.addPassenger();
    elevator.addPassenger(); // this passenger will not fit
    elevator.removePassenger();
    elevator.removePassenger();

    

    // move elevator
    cout << "Moving elevator..." << endl;
    while (elevator.getNumPassengers() > 0 || !elevator.getFloorsToVisit().empty()) {
        int desiredFloor;
        cout << "Enter desired floor: ";
        cin >> desiredFloor;
        elevator.requestFloor(desiredFloor);
        elevator.move();
        cout << "Current floor: " << elevator.getCurrentFloor() << endl;
    }

    return 0;
}
